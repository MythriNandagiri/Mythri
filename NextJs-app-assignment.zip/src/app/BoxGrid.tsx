"use client";

import { useState } from 'react';

const BoxGrid = () => {
    const [activePage, setActivePage] = useState<string | null>(null);

    const links = [
        { href: "/page1", label: "Page 1" },
        { href: "/page2", label: "Page 2" },
        { href: "/page3", label: "Page 3" },
        { href: "/page4", label: "Page 4" },
        { href: "/page5", label: "Page 5" },
        { href: "/page6", label: "Page 6" },
        { href: "/page7", label: "Page 7" },
        { href: "/page8", label: "Page 8" },
    ];

    const handleClick = (href: string) => {
        setActivePage(href);
    };

    return (
        <div className="flex flex-wrap justify-center gap-4 p-4">
            {links.map(({ href, label }) => (
                <a
                    key={href}
                    href={href}
                    onClick={() => handleClick(href)}
                    className={`flex items-center justify-center w-32 h-32 
                        ${activePage === href ? 'border-4 border-dark' : ''} 
                        bg-blue-500 text-white rounded-lg shadow-lg 
                        hover:bg-blue-600 transition duration-200`}
                >
                    {label}
                </a>
            ))}
        </div>
    );
};

export default BoxGrid;
