const Navbar = () => {
    return (
      <nav className="bg-gray-800 p-4">
        <div className="container mx-auto flex justify-between">
          <a href="/" className="text-white">SocialX</a>
          <div>
            <a href="/cart" className="text-white">Cart</a>
          </div>
        </div>
      </nav>
    );
  };
  
  export default Navbar;
  