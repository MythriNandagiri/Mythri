"use client";


import Image from "next/image";
import RootLayout from "./layout"

import Sidebar from  "../components/Sidebar"
import BoxGrid from "./BoxGrid";

export default function Home() {
  return (
    <main className="p-4 bg-white dark:bg-black text-black dark:text-white">
      <div className="flex">
      <Sidebar />
      <BoxGrid />
      </div>

    </main>
  );
}
